#ifndef RESOURCE_H
#define RESOURCE_H

#include "datafile.h"


#endif
