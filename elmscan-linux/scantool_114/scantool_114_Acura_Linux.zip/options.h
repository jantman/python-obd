#ifndef OPTIONS_H
#define OPTIONS_H

int display_options();
void load_program_options();
void save_program_options();

#endif
