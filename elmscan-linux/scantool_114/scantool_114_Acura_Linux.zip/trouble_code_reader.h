#ifndef TROUBLE_CODE_READER_H
#define TROUBLE_CODE_READER_H

int display_trouble_codes();

#endif
