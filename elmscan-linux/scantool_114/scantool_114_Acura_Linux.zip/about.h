#ifndef ABOUT_H
#define ABOUT_H

int display_about();

#endif
