#ifndef RESET_H
#define RESET_H

void reset_chip();

#endif
