#ifndef ERROR_HANDLERS_H
#define ERROR_HANDLERS_H

char temp_error_buf[256];

void fatal_error(char *msg);

#endif
