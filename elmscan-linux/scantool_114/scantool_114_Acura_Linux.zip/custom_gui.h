#ifndef CUSTOM_GUI_H
#define CUSTOM_GUI_H

int nostretch_icon_proc(int msg, DIALOG *d, int c);
int super_textbox_proc(int msg, DIALOG *d, int c);
int caption_proc(int msg, DIALOG *d, int c);
int st_ctext_proc(int msg, DIALOG *d, int c);

#endif
