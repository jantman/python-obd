#ifndef SENSORS_H
#define SENSORS_H

int display_sensor_dialog(int reset);

extern void obd_requirements_formula(int data, char *buf);

#endif
