#ifndef MAIN_MENU_H
#define MAIN_MENU_H

int display_main_menu();

#endif
