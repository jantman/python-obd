/* Allegro datafile object indexes, produced by grabber v4.0.1, djgpp */
/* Datafile: scantool.dat */
/* Date: Fri May 31 16:50:51 2002 */
/* Do not hand edit! */

#define ABOUT1_BMP                       0        /* BMP  */
#define ABOUT2_BMP                       1        /* BMP  */
#define ABOUT3_BMP                       2        /* BMP  */
#define ARIAL12_BOLD_FONT                3        /* FONT */
#define ARIAL12_FONT                     4        /* FONT */
#define ARIAL18_FONT                     5        /* FONT */
#define EXIT1_BMP                        6        /* BMP  */
#define EXIT2_BMP                        7        /* BMP  */
#define EXIT3_BMP                        8        /* BMP  */
#define FREEZE_FRAME1_BMP                9        /* BMP  */
#define FREEZE_FRAME2_BMP                10       /* BMP  */
#define FREEZE_FRAME3_BMP                11       /* BMP  */
#define INEXPENSIVE_ALTERNATIVES_BMP     12       /* BMP  */
#define LOGO_BMP                         13       /* BMP  */
#define MAIN_PALETTE                     14       /* PAL  */
#define MIL_OFF_BMP                      15       /* BMP  */
#define MIL_ON_BMP                       16       /* BMP  */
#define OPTIONS1_BMP                     17       /* BMP  */
#define OPTIONS2_BMP                     18       /* BMP  */
#define OPTIONS3_BMP                     19       /* BMP  */
#define READ_CODES1_BMP                  20       /* BMP  */
#define READ_CODES2_BMP                  21       /* BMP  */
#define READ_CODES3_BMP                  22       /* BMP  */
#define SENSOR_DATA1_BMP                 23       /* BMP  */
#define SENSOR_DATA2_BMP                 24       /* BMP  */
#define SENSOR_DATA3_BMP                 25       /* BMP  */
#define SUNFIRE_BMP                      26       /* BMP  */
#define TESTS1_BMP                       27       /* BMP  */
#define TESTS2_BMP                       28       /* BMP  */
#define TESTS3_BMP                       29       /* BMP  */

